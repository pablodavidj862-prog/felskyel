# How to jump in !


⭐ To edit the code : Open the extracted folder in your favourite IDE (example : VSCode)

⭐ To see the result : Open index.html in a browser